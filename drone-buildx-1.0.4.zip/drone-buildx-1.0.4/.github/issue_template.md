<!-- PLEASE READ BEFORE DELETING

Bugs or Issues? Due to the high number of false positive issues we receive,
please do not create a GitHub issue until you have discussed and verified
with community support at:

    https://discourse.drone.io/

-->
