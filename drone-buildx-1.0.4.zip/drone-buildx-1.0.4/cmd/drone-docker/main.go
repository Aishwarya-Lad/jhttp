package main

import (
	docker "github.com/drone-plugins/drone-buildx"
)

func main() {
	docker.Run()
}
